(function(){
    angular.module('App')
    .component('learningsDashboard', {
        templateUrl: _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/learnings-dashboard/learningsDashboard-view.html?rnd' + Math.random(),
        bindings: {
            //user: '<'
        },
        controllerAs: 'ctrl',
        controller: ['$ApiService', '$q', '$scope', '$routeParams', '$uibModal', '$window', '$location', formCtrl]
    });

    function formCtrl($ApiService, $q, $scope, $routeParams, $uibModal, $window, $location){
        var ctrl = this;
        ctrl.items = [];
        ctrl.userTopicsLog = [];
        ctrl.topicsLog = [];
        getData();
        function getData(){
            var request = {
                userTopicsLog: $ApiService.getListItems('LearningsTopicsLog', '$filter=UserId eq ' + _spPageContextInfo.userId),
                userTopics: $ApiService.getListItems('LearningsTopics', ''),
                topicsLog: $ApiService.getListItems('TopicsLog', '$select=*,Author/Title,Author/Id,Author/EMail,Topic/Title&$expand=Author,Topic&$filter=AuthorId eq ' + _spPageContextInfo.userId),
                allTopics: $ApiService.getListItems('Topics', ''),
            };

            $q.all(request).then(function(res){
                ctrl.userTopicsLog = res.userTopicsLog;
                if(ctrl.userTopicsLog.length){
                    ctrl.userTopicsLog = [];
                    angular.forEach(res.userTopicsLog, function(value){
                        angular.forEach(res.userTopics, function(v){
                            if(value.LearningsTopicId == v.Id) {
                                var newItem = value;
                                newItem.LearningsTopic = v;
                                ctrl.userTopicsLog.push(newItem);
                            }
                        });
                    });
                }
                if(res.topicsLog.length) {
                    ctrl.topicsLog = [];
                    angular.forEach(res.topicsLog, function(value){
                        angular.forEach(res.allTopics, function(v){
                            if(value.TopicId == v.Id) {
                                var newItem = value;
                                newItem.Topic = v;
                                ctrl.topicsLog.push(newItem);
                            }
                        });
                    });
                }
            });
        }
        ctrl.getTopicLogItem = function(topicId){
            var topicLog = ctrl.userTopicsLog.filter(function(f){
                return f.TopicId == topicId;
            });
            return topicLog.length ? topicLog[0] : null;
        }

        ctrl.onClickTopic = function(topic){
            if(topic.openInNewTab) {
                ctrl.openInNewTab(topic.StartLink ? topic.StartLink.Url : '')
            }
            else {
                ctrl.openModal(topic.Topic.Title, topic.StartLink ? topic.StartLink.Url : '')
            }
        }
        ctrl.onCompleteTopic = function(itemId){
            $ApiService.updateItem('TopicsLog', itemId, {Status: 'Completed', __metadata: {type:'SP.Data.TopicsLogListItem'}}).then(function(res){
                getData();
            });
        }
        ctrl.onClickUserTopic = function(topic){
            $ApiService.updateItem('LearningsTopicsLog', topic.Id, {Status: 'In Progress', __metadata: {type:'SP.Data.LearningsTopicsLogListItem'}}).then(function(res){
                getData();
                if(topic.openInNewTab) {
                    ctrl.openInNewTab(topic.StartLink ? topic.StartLink.Url : '')
                }
                else {
                    ctrl.openModal(topic.LearningsTopic.Title, topic.StartLink ? topic.StartLink.Url : '')
                }
            });
        }
        ctrl.onCompleteUserTopic = function(itemId){
            $ApiService.updateItem('LearningsTopicsLog', itemId, {Status: 'Completed', __metadata: {type:'SP.Data.LearningsTopicsLogListItem'}}).then(function(res){
                getData();
            });
        }

        ctrl.openInNewTab = function(url){
            var win = window.open(url, '_blank');
            win.focus();
        }

        ctrl.openModal = function(title, url) {
            var modalInstance = $uibModal.open({
                animation: true,
                size: 'xl',
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                template: '<div class="modal-header">'+
                        '<button type="button" class="close" data-dismiss="modal" ng-click="ctr.cancel()" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
                        '<h2 class="modal-title text-center" id="modal-title">'+title+'</h2>'+
                    '</div>'+
                    '<div class="modal-body"><iframe width="100%" height="'+($window.innerHeight-150)+'px" src="'+url+'"</div>',
                controller: function($uibModalInstance){
                    var ctr = this;
                    ctr.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                      };
                },
                controllerAs: 'ctr',
                appendTo: angular.element(document.querySelectorAll('.app-container')),
                resolve: {}
            });
        }

        ctrl.collapseOther = function(id, itemId) {
            var list = $(".topic-description.collapse");
            $.each(list, function(key, el) {
                if($(el).attr('id') !== id) {
                    $(el).collapse('hide');
                }

            });
            $.each(ctrl.items, function(key, item) {
                if(item.Id != itemId) {
                    item.collapse = false;
                }
                if(item.Id == itemId) {
                    item.collapse = !item.collapse;
                }

            });

        }

        ctrl.getTopicHours = function(val){
            if(!val) return 0+' min';
            var result = '';
            if(val<60){
                result = val + ' min';
            }
            else {
                result = parseInt(val/60) + ' hour '+ (val%60) + ' min';
            }
            return result;
        }	
    }
})();