(function(){
    angular.module('App')
    .component('portalCards', {
        templateUrl: _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/portal-cards/portalCards-view.html?rnd' + Math.random(),
        bindings: {
            //user: '<'
        },
        controllerAs: 'ctrl',
        controller: ['$ApiService', '$q', '$scope', '$routeParams', '$uibModal', '$window', '$location', 'CONSTANTS', formCtrl]
    });

    function formCtrl($ApiService, $q, $scope, $routeParams, $uibModal, $window, $location, CONSTANTS){
		$('#link-style').remove();
        var ctrl = this;
        ctrl.CONSTANTS = CONSTANTS;
        ctrl.parentLinkId = $routeParams.parentLinkId;
        ctrl.allCategories = [];
        ctrl.groupedMainLinks = [];
        ctrl.allLinks = [];
        ctrl.cardParentLink = {};
        ctrl.hoverSlide = null;
        ctrl.defaultImage = 'https://bhmlib.org/wp-content/themes/cosimo-pro/images/no-image-box.png';
        var request = {
            allCategory: $ApiService.getListItems('LinksCategories', '$orderBy=SortOrder'),
            allMainLinks: $ApiService.getListItems('MainLinks', "$orderBy=SortOrder&$filter=Status eq 'Active'"),
            learningsUser: $ApiService.getListItems('LearningsUsers', '$filter=UserId eq ' + _spPageContextInfo.userId),
            topicsLog: $ApiService.getListItems('LearningsTopicsLog', '$filter=UserId eq ' + _spPageContextInfo.userId),
        };

        $q.all(request).then(function(res){
            ctrl.allCategories = res.allCategory;
            ctrl.groupedMainLinks = groupBy(res.allMainLinks, 'CategoryId');
            if((ctrl.CONSTANTS.Survey && res.topicsLog == 0 && !sessionStorage.getItem("delayShowLearnigModal")) || 
                (ctrl.CONSTANTS.Survey && res.learningsUser.length == 0 && !sessionStorage.getItem("delayShowLearnigModal"))){
                ctrl.openLearningsModal();
            }
        });
        ctrl.showControls = true;
        angular.element($window).bind('resize', function(){
            checkShowControls();
        })
        ctrl.goToDiscussionBoard = function(e){
            e.preventDefault();
            localStorage.setItem('learning', JSON.stringify({path: $location.path()}));
            location.href = "https://thebank.info53.com/sites/RetailLearn/PBNK/Dev/topics/SiteAssets/app/Portal.aspx"
        }

        ctrl.loadLastTopic = function(e){
            e.preventDefault();
            $ApiService.getListItems('TopicsLog', "$orderBy=Modified desc&top=1&$filter=AuthorId eq "+_spPageContextInfo.userId)
            .then(function(data){
                if(data.length){
                    var topicLogItem = data[0];
                    $ApiService.getListItems('Subcards Links', "$select=*,ParentLink/Title&$expand=ParentLink&$filter=Id eq "+topicLogItem.SubcardsLinkId)
                    .then(function(res){
                        if(res.length){
                            $location.path('/'+res[0].ParentLinkId);
                            ctrl.open(res[0]);
                            setTimeout(function(){
                                var list = $(".topic-description");
                                $.each(list, function(key, el) {
                                    if($(el).attr('item-id') == topicLogItem.TopicId) {
                                        $(el).collapse('show');
                                    }
                                });
                            },1000)
                        }
                    });
                }
            });
        };

        ctrl.showPrev = function(){
            if($('#slider ul li:first-child .index').attr('index') != 0) {
                return true;
            }
            else return false;
        }

        ctrl.showNext = function(){
            var offset = 0;
            if($window.innerWidth <= 900 && ctrl.allLinks.length > 2)
            {
                offset = 1;                
            }
            else if(($window.innerWidth > 900 && $window.innerWidth <= 1366) && ctrl.allLinks.length > 3)
            {
                offset = 2; 
            }
            else if($window.innerWidth > 1366 && ctrl.allLinks.length > 5)
            {
                offset = 4;
            }
            if($('#slider ul li:eq('+offset+') .index').attr('index') != ctrl.allLinks.length-1) {
                return true;
            }
            else return false;
        }

        function checkShowControls(){
            if($window.innerWidth <= 900 && ctrl.allLinks.length <= 2)
            {
                setTimeout(function(){
                    $scope.$apply(function(){
                        ctrl.showControls = false;
                    });
                },0);                
            }
            else if(($window.innerWidth > 900 && $window.innerWidth <= 1366) && ctrl.allLinks.length <= 3)
            {
                setTimeout(function(){
                    $scope.$apply(function(){
                        ctrl.showControls = false;
                    });
                },0);
            }
            else if($window.innerWidth > 1366 && ctrl.allLinks.length <= 5)
            {
                setTimeout(function(){
                    $scope.$apply(function(){
                        ctrl.showControls = false;
                    });
                },0);
            }
            else {
                setTimeout(function(){
                    $scope.$apply(function(){
                        ctrl.showControls = true;
                    });
                },0);
            }
        }

        if(ctrl.parentLinkId){
            var request = {
                parentItem: $ApiService.getListItems('Cards', '$select=*,ParentLink/Title,ParentLink/Id&$expand=ParentLink&$orderBy=SortOrder&$filter=Id eq '+ ctrl.parentLinkId),
                items: $ApiService.getListItems('Subcards Links', "$orderBy=SortOrder&$select=*,ParentLink/Title&$expand=ParentLink&$filter=Status eq 'Active' and ParentLinkId eq "+ctrl.parentLinkId),
            };
            $q.all(request).then(function(res){
                ctrl.cardParentLink = res.parentItem[0].ParentLink;
                ctrl.allLinks = res.items;
                checkShowControls();
                var slideCount = $('#slider ul li').length;
                var slideWidth = $('#slider ul li').width();
                var slideHeight = $('#slider ul li').height();
                var sliderUlWidth = slideCount * slideWidth;
                
                // $('#slider').css({ width: slideWidth, height: slideHeight });
                
                $('#slider ul').css({ width: sliderUlWidth, marginLeft: - slideWidth });
                
                $('#slider ul li:last-child').prependTo('#slider ul');
                $('body .app-container').before('<link id="link-style" href="'+ _spPageContextInfo.webServerRelativeUrl + "/SiteAssets/app/Leadership/app/components/portal-cards/portalCards-links-style.css?rnd" + Math.random() +'" rel="stylesheet">')

            }).catch(function(e){
                $('body .app-container').before('<link id="link-style" href="'+ _spPageContextInfo.webServerRelativeUrl + "/SiteAssets/app/Leadership/app/components/portal-cards/portalCards-links-style.css?rnd" + Math.random() +'" rel="stylesheet">')
            });
        }

        

        ctrl.moveLeft = function() {
            if($('#slider ul li:first-child .index').attr('index') == 0) return;
            $('#slider ul').animate({
                left: + $('#slider ul li').width()
            }, 200, function () {
                $('#slider ul li:last-child').prependTo('#slider ul');
                $('#slider ul').css('left', '');
                $scope.$apply();
            });
        };

        ctrl.moveRight = function() {
            var offset = 0;
            if($window.innerWidth <= 900 && ctrl.allLinks.length > 2)
            {
                offset = 1;                
            }
            else if(($window.innerWidth > 900 && $window.innerWidth <= 1366) && ctrl.allLinks.length > 3)
            {
                offset = 2; 
            }
            else if($window.innerWidth > 1366 && ctrl.allLinks.length > 5)
            {
                offset = 4;
            }
            if($('#slider ul li:eq('+offset+') .index').attr('index') == ctrl.allLinks.length-1) return;
            $('#slider ul').animate({
                left: - $('#slider ul li').width()
            }, 200, function () {
                $('#slider ul li:first-child').appendTo('#slider ul');
                $('#slider ul').css('left', '');
                $scope.$apply();
            });
        };

        ctrl.moveOnStart = function(){
            var curIndex = parseInt($('#slider ul>li:first-child .read-more>.index').attr('index'));
            if(curIndex==0) return;
            for(var i=0;i<(curIndex);i++){
                ctrl.moveLeft();
            }
        }
        ctrl.moveOnEnd = function(){
            var curIndex = parseInt($('#slider ul>li:first-child .read-more>.index').attr('index'));
            if(curIndex==ctrl.allLinks.length-1) return;
            var offset = 0;
            if($window.innerWidth <= 900 && ctrl.allLinks.length > 2)
            {
                offset = 1;                
            }
            else if(($window.innerWidth > 900 && $window.innerWidth <= 1366) && ctrl.allLinks.length > 3)
            {
                offset = 2; 
            }
            else if($window.innerWidth > 1366 && ctrl.allLinks.length > 5)
            {
                offset = 4;
            }
            for(var i=0;i<(ctrl.allLinks.length-(curIndex+1)-offset);i++){
                ctrl.moveRight();
            }
        }
        
        ctrl.openLearningsModal = function () {
            var modalInstance = $uibModal.open({
                animation: true,
                size: 'md',
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                templateUrl: _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/modal/learningsSurvey-modal.html',
                controller: function($uibModalInstance){
                    var ctrl = this;
                    ctrl.ok = function () {
                        $uibModalInstance.close();
                        $location.path('/learnings-survey');
                    };
                    
                    ctrl.cancel = function () {
                        sessionStorage.setItem('delayShowLearnigModal', "true");
                        $uibModalInstance.dismiss('cancel');
                    };
                },
                controllerAs: 'ctrl',
                appendTo: angular.element(document.querySelectorAll('.app-container')),
                resolve: {}
			});
		}
        ctrl.open = function (item, e) {
            if(e) e.preventDefault();
            if(item.ExternalLink && item.ExternalLink.Url){
                window.open(item.ExternalLink.Url, '_blank');
            }
            else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    size: 'lg',
                    ariaLabelledBy: 'modal-title',
                    ariaDescribedBy: 'modal-body',
                    templateUrl: _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/modal/modal-view.html',
                    controller: modalCtrl,
                    controllerAs: 'ctrl',
                    appendTo: angular.element(document.querySelectorAll('.app-container')),
                    resolve: {
                        item: function () {
                            return item;
                        }
                    }
                });
            }
		}

        function modalCtrl($uibModalInstance, $scope, CONSTANTS, item ) {
            var ctrl = this;
            ctrl.CONSTANTS = CONSTANTS;
            ctrl.item = item;
            ctrl.items = [];
            ctrl.topicsLog = [];
            var newReq = [];
            newReq.push($ApiService.getListItems('Topics', '$orderBy=SortOrder&$filter=SubcardsLink eq '+item.Id));
            newReq.push($ApiService.getListItems('TopicsLog', "$filter=AuthorId eq "+_spPageContextInfo.userId));
            Promise.all(newReq)
            .then(function(res){
                setTimeout(function(){
                    ctrl.items = res[0];
                    ctrl.topicsLog = res[1]; 
                    $scope.$apply();   
                },0);

            });

            ctrl.onCompleteTopic = function(itemId){
                $ApiService.updateItem('TopicsLog', itemId, {Status: 'Completed', __metadata: {type:'SP.Data.TopicsLogListItem'}}).then(function(res){
                    $ApiService.getListItems('TopicsLog', "$filter=AuthorId eq "+_spPageContextInfo.userId).then(function(data){
                        ctrl.topicsLog = data;
                    });
                });
            }

            ctrl.onClickTopic = function(topic){
                var tipicLogItem = ctrl.getTopicLogItem(topic.Id);
                if(!tipicLogItem){
                    $ApiService.createItem('TopicsLog', {
                        TopicId: topic.Id, 
                        Status: 'In Progress', 
                        SubcardsLinkId: topic.SubcardsLinkId,
                        __metadata: {type:'SP.Data.TopicsLogListItem'}
                    }).then(function(res){
                        $ApiService.getListItems('TopicsLog', "$filter=AuthorId eq "+_spPageContextInfo.userId).then(function(data){
                            ctrl.topicsLog = data;
                        });
                        if(topic.openInNewTab) {
                            ctrl.openInNewTab(topic.StartLink ? topic.StartLink.Url : '')
                        }
                        else {
                            ctrl.openModal(topic.Title, topic.StartLink ? topic.StartLink.Url : '')
                        }
                    });
                }
                else {
                    if(topic.openInNewTab) {
                        ctrl.openInNewTab(topic.StartLink ? topic.StartLink.Url : '')
                    }
                    else {
                        ctrl.openModal(topic.Title, topic.StartLink ? topic.StartLink.Url : '')
                    }
                }
            }

            ctrl.getTopicLogItem = function(topicId){
                var topicLog = ctrl.topicsLog.filter(function(f){
                    return f.TopicId == topicId;
                });
                return topicLog.length ? topicLog[0] : null;
            }

            ctrl.openInNewTab = function(url){
                var win = window.open(url, '_blank');
                win.focus();
            }

            ctrl.openModal = function(title, url) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    size: 'xl',
                    ariaLabelledBy: 'modal-title',
                    ariaDescribedBy: 'modal-body',
                    template: '<div class="modal-header">'+
                            '<button type="button" class="close" data-dismiss="modal" ng-click="ctr.cancel()" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
                            '<h2 class="modal-title text-center" id="modal-title">'+title+'</h2>'+
                        '</div>'+
                        '<div class="modal-body"><iframe name="topicWindow" width="100%" height="'+($window.innerHeight-150)+'px" src="'+url+'"</div>',
                    controller: function($uibModalInstance){
                        var ctr = this;
                        ctr.cancel = function () {
                            $uibModalInstance.dismiss('cancel');
                          };
                    },
                    controllerAs: 'ctr',
                    appendTo: angular.element(document.querySelectorAll('.app-container')),
                    resolve: {}
                });
            }

            ctrl.collapseOther = function(id, itemId) {
                var list = $(".topic-description.collapse");
                $.each(list, function(key, el) {
                    if($(el).attr('id') !== id) {
                        $(el).collapse('hide');
                    }

                });
                $.each(ctrl.items, function(key, item) {
                    if(item.Id != itemId) {
                        item.collapse = false;
                    }
                    if(item.Id == itemId) {
                        item.collapse = !item.collapse;
                    }

                });

            }
			ctrl.getSumTopicsHours = function(items){
				if(!items || items.length == 0) return 0+' min';
				var result = '';
				var sum = 0;
				angular.forEach(items, function(item){
					sum += item.Time ? parseInt(item.Time) : 0;
				});
				if(sum<60){
					result = sum + ' min';
				}
				else {
					result = parseInt(sum/60) + ' hour '+ (sum%60) + ' min';
				}
				return result;
			}	
			ctrl.getTopicHours = function(val){
				if(!val) return 0+' min';
				var result = '';
				if(val<60){
					result = val + ' min';
				}
				else {
					result = parseInt(val/60) + ' hour '+ (val%60) + ' min';
				}
				return result;
			}				

            ctrl.ok = function () {
            //   $uibModalInstance.close(ctrl.selected.item);
            };
          
            ctrl.cancel = function () {
              $uibModalInstance.dismiss('cancel');
            };
          }

        function groupBy(xs, prop) {
            return xs.reduce(function(rv, x) {
              (rv[x[prop]] = rv[x[prop]] || []).push(x);
              return rv;
            }, {});
        }
    }
})();
