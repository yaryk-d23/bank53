(function(){
    angular.module('App')
    .component('siteHeader', {
        templateUrl: _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/site-header/siteHeader-view.html?rnd' + Math.random(),
        bindings: {
            //user: '<'
        },
        controllerAs: 'ctrl',
        controller: ['$ApiService', '$q', '$scope', 'CONSTANTS', formCtrl]
    });

    function formCtrl($ApiService, $q, $scope, CONSTANTS){
        var ctrl = this;
        ctrl.CONSTANTS = CONSTANTS;
        ctrl.homeUrl = _spPageContextInfo.webAbsoluteUrl;
    }
})();