(function(){
    angular.module('App')
    .component('learnings', {
        templateUrl: _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/learnings/learnings-view.html?rnd' + Math.random(),
        bindings: {
            //user: '<'
        },
        controllerAs: 'ctrl',
        controller: ['$ApiService', '$q', '$scope', '$routeParams', '$uibModal', '$window', '$location', formCtrl]
    });

    function formCtrl($ApiService, $q, $scope, $routeParams, $uibModal, $window, $location){
        var ctrl = this;
        ctrl.categories = [];
        ctrl.allQuestions = [];
        ctrl.configItems = [];
        ctrl.currentSlide = 0;
        var request = {
            categories: $ApiService.getListItems('LearningCategories', '$orderby=SortOrder'),
            allQuestions: $ApiService.getListItems('LearningsSurveyQuestions', ''),
            configItems: $ApiService.getListItems('LearningsConfig', ''),
            learningsUser: $ApiService.getListItems('LearningsUsers', '$filter=UserId eq ' + _spPageContextInfo.userId),
            topicsLog: $ApiService.getListItems('LearningsTopicsLog', '$filter=UserId eq ' + _spPageContextInfo.userId),
        };

        $q.all(request).then(function(res){
            if(res.learningsUser.length != 0 && res.topicsLog != 0){
                $location.path('/learnings-dashboard');
            }
            ctrl.categories = res.categories;
            ctrl.configItems = res.configItems;
            angular.forEach(res.allQuestions, function(value,key){
                value.Answers = value.Answers.split(/\n/);
            });
            ctrl.allQuestions = groupBy(res.allQuestions, 'CategoryId');
        });

        ctrl.prevSlide = function() {
            ctrl.currentSlide = ctrl.currentSlide - 1;
        }
        ctrl.nextSlide = function(){
            ctrl.currentSlide = ctrl.currentSlide + 1;
        }

        ctrl.close = function(){
            $location.path('/');
        }
        function groupBy(xs, prop) {
            return xs.reduce(function(rv, x) {
              (rv[x[prop]] = rv[x[prop]] || []).push(x);
              return rv;
            }, {});
        }
        ctrl.save = function(){
            var requests = [];
            var topicsIds = [];
            angular.forEach(ctrl.categories, function(category){
                angular.forEach(ctrl.allQuestions[category.Id], function(value,key){
                    requests.push(
                        $ApiService.createItem('LearningsSurveyAnswers', {
                            QuestionId: value.Id,
                            Answer: value.Answer,
                            OtherAnswer: value.OtherAnswer,
                            '__metadata': {
                                type: 'SP.Data.LearningsSurveyAnswersListItem'
                            },
                        })
                    );

                    angular.forEach(ctrl.configItems, function(v,k){
                        if(v.QuestionId == value.Id && v.Answer == value.Answer) {
                            topicsIds.push(v);
                        }
                    });
                });
            });
            $q.all(requests).then(function(res) {
                requests = [];
                angular.forEach(topicsIds, function(value,key){
                    requests.push(
                        $ApiService.createItem('LearningsTopicsLog', {
                            Title: value.Title,
                            LearningsTopicId: value.TopicId,
                            TopicType: 'Individual',
                            Status: 'New',
                            UserId: _spPageContextInfo.userId,
                            '__metadata': {
                                type: 'SP.Data.LearningsTopicsLogListItem'
                            },
                        })
                    );
                });
                requests.push(
                    $ApiService.createItem('LearningsUsers', {
                        UserId: _spPageContextInfo.userId,
                        '__metadata': {
                            type: 'SP.Data.LearningsUsersListItem'
                        },
                    })
                );
                $q.all(requests).then(function(res) {
                    $location.path('/learnings-dashboard');

                });
                
            });
            
        }
    }
})();