(function(){
    angular.module('App')
    .component('managerDashboard', {
        templateUrl: _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/manager-dashboard/managerDashboard-view.html?rnd' + Math.random(),
        bindings: {
            //user: '<'
        },
        controllerAs: 'ctrl',
        controller: ['$ApiService', '$q', '$scope', '$routeParams', '$uibModal', '$window', '$location', '$http', '$GeneratePDF', formCtrl]
    });

    function formCtrl($ApiService, $q, $scope, $routeParams, $uibModal, $window, $location, $http, $GeneratePDF){
        var ctrl = this;
        ctrl.allUsers = [];
        ctrl.userId = $routeParams.userId;
        ctrl.selectedUser = null;
        ctrl.userTopics = [];

        ctrl.allUserTopics = [];
        ctrl.allUserTopicsLog = [];
        ctrl.topicsLog = [];
        ctrl.allTopics = [];

        getData();
        function getData() {
            ctrl.allUsers = [];
            if(ctrl.userId) {
                $ApiService.getListItems('LearningsUsers', '$select=*,User/Title,User/Id,User/EMail&$expand=User&$filter=UserId eq ' + ctrl.userId)
                .then(function(res){
                    if(res[0]){
                        ctrl.selectedUser = res[0];
                    }
                });
                var request = {
                    user: $ApiService.getListItems('LearningsUsers', '$select=*,User/Title,User/Id,User/EMail&$expand=User&$filter=UserId eq ' + ctrl.userId),
                    userTopics: $ApiService.getListItems('LearningsTopicsLog', '$filter=UserId eq ' + ctrl.userId),
                    allUserTopics: $ApiService.getListItems('LearningsTopics', '$orderby=TopicType'),
                };
        
                $q.all(request).then(function(res){
                    if(res.user[0]){
                        ctrl.selectedUser = res.user[0];
                    }
                    ctrl.userTopics = [];
                    angular.forEach(res.userTopics, function(value){
                        angular.forEach(res.allUserTopics, function(v){
                            if(value.LearningsTopicId == v.Id) {
                                var newItem = value;
                                newItem.LearningsTopic = v;
                                ctrl.userTopics.push(newItem);
                            }
                        });
                    });
                    ctrl.allUserTopics = res.allUserTopics;
                });
            }
            $ApiService.getListItems('LearningsManagers', '$select=*,Users/Title,Users/Id,Users/EMail&$expand=Users&$filter=ManagerId eq ' + _spPageContextInfo.userId)
            .then(function(res) {
                if(res && res[0]){
                    angular.forEach(res[0].Users, function(val){
                        ctrl.allUsers.push({User: val});
                    });
                    var usersFilter = [];
                    var authorFilter = [];
                    angular.forEach(res[0].UsersId, function(id){
                        usersFilter.push('UserId eq ' + id);
                        authorFilter.push('AuthorId eq ' + id);
                    });
                    if(!usersFilter.length) {
                        usersFilter.push('UserId eq 0');
                    }
                    if(!authorFilter.length) {
                        authorFilter.push('AuthorId eq 0');
                    }
                    var request = {
                        // allUsers: $ApiService.getListItems('LearningsUsers', '$select=*,User/Title,User/Id,User/EMail&$expand=User&$'),
                        topicsLog: $ApiService.getListItems('TopicsLog', '$select=*,Author/Title,Author/Id,Author/EMail,Topic/Title&$expand=Author,Topic&$filter='+authorFilter.join(' or ')),
                        allTopics: $ApiService.getListItems('Topics', ''),
                        userTopics: $ApiService.getListItems('LearningsTopicsLog', '$select=*,User/Title,User/EMail,User/Id&$expand=User&$filter='+usersFilter.join(' or ')),
                        // user: $http.get('https://thebank.info53.com/sites/RetailLearn/BBNewHire/_api/SP.UserProfiles.PeopleManager/GetMyProperties')
                    };
            
                    $q.all(request).then(function(res){
                        // ctrl.allUsers = res.allUsers;
                        ctrl.allUserTopicsLog = groupBy(res.userTopics, 'UserId');
                        ctrl.topicsLog = [];
                        angular.forEach(res.topicsLog, function(value){
                            angular.forEach(res.allTopics, function(v){
                                if(value.TopicId == v.Id) {
                                    var newItem = value;
                                    newItem.Topic = v;
                                    ctrl.topicsLog.push(newItem);
                                }
                            });
                        });
                        ctrl.topicsLog = groupBy(ctrl.topicsLog, 'AuthorId');

                        // angular.forEach(ctrl.allUserTopicsLog, function(value, key){
                        //     ctrl.allUsers.push({User: value[0].User});
                        // });
                        // angular.forEach(ctrl.topicsLog, function(value, key){
                        //     var isExist = false;
                        //     angular.forEach(ctrl.allUsers, function(user){
                        //         if(user.User.Id == value[0].Author.Id){
                        //             isExist = true;
                        //         }
                        //     });
                        //     if(!isExist) {
                        //         ctrl.allUsers.push({User: value[0].Author});
                        //     }
                            
                        // });

                    });
                }
            });
        }

        ctrl.collapseOther = function(id, itemId) {
            var list = $(".topic-description.collapse");
            $.each(list, function(key, el) {
                if($(el).attr('id') !== id) {
                    $(el).collapse('hide');
                }

            });
            $.each(ctrl.items, function(key, item) {
                if(item.Id != itemId) {
                    item.collapse = false;
                }
                if(item.Id == itemId) {
                    item.collapse = !item.collapse;
                }

            });

        }
        ctrl.removeUser = function(user){
            var modalInstance = $uibModal.open({
                animation: true,
                size: 'md',
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                template: '<div>'+
                    '<div class="modal-header">'+
                        '<button type="button" class="close" data-dismiss="modal" ng-click="ctrl.cancel()" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
                        '<h2 class="modal-title text-center" id="modal-title">Remove {{ctrl.user.Title}} ?</h2>'+
                    '</div>'+
                    '<div class="modal-footer">'+
                        '<button class="btn btn-primary" type="button" ng-click="ctrl.cancel()">Close</button>'+
                        '<button class="btn btn-danger" type="button" ng-click="ctrl.ok()">Remove</button>'+
                    '</div>'+
                '</div>',
                controller: function($uibModalInstance, user){
                    var ctrl = this;
                    ctrl.user = user;
                    ctrl.ok = function () {
                        $uibModalInstance.close(ctrl.user);
                    };
                    
                    ctrl.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                    };
                },
                controllerAs: 'ctrl',
                appendTo: angular.element(document.querySelectorAll('.app-container')),
                resolve: {
                    user: function(){
                        return user;
                    }
                }
            });
            modalInstance.result.then(function (user) {
                removeUserFromList(user);
            }, function () {
            });
        }

        function removeUserFromList(user) {
            $ApiService.getListItems('LearningsManagers', '$select=*,Users/Title,Users/Id,Users/EMail&$expand=Users&$filter=ManagerId eq ' + _spPageContextInfo.userId)
            .then(function(res){
                if(res[0]) {
                    var ids = res[0].UsersId.filter(function(id){return id != user.Id;});
                    $ApiService.updateItem('LearningsManagers', res[0].Id, {
                        UsersId: {
                            results: ids
                        },
                        '__metadata': {
                            type: 'SP.Data.LearningsManagersListItem'
                        },
                    }).then(function(res){
                        getData();
                    })

                }
            });
        }

        ctrl.addUser = function () {
            var modalInstance = $uibModal.open({
                animation: true,
                size: 'md',
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                template: '<div>'+
                    '<div class="modal-header">'+
                        '<button type="button" class="close" data-dismiss="modal" ng-click="ctrl.cancel()" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
                        '<h2 class="modal-title text-center" id="modal-title">Add user to learning dashboard</h2>'+
                    '</div>'+
                    '<div class="modal-body" id="modal-body">'+
                    '<div>'+
                        '<div class="form-group">'+
                            '<label for="User">User</label>'+
                            '<ui-select ng-model="ctrl.user" theme="bootstrap" close-on-select="true" title="Choose a person" >'+
                                '<ui-select-match placeholder="Select person...">{{$select.selected.Title}} &lt;{{$select.selected.Email}}&gt;</ui-select-match>'+
                                '<ui-select-choices refresh="ctrl.getUsers($select)" refresh-delay="0" repeat="user as user in ctrl.allUsers | propsFilter: {Title: $select.search}">'+
                                    '<div ng-bind-html="user.Title | highlight: $select.search"></div>'+
                                    '<small> email: {{user.Email}} </small>'+
                                '</ui-select-choices>'+
                                '<ui-select-no-choice>'+
                                    '<span style="padding: 0 10px;">No results found or user already selected!</span>'+
                                '</ui-select-no-choice>'+
                            '</ui-select>'+
                        '</div>'+
                    '</div>'+
                    '</div>'+
                    '<div class="modal-footer">'+
                        '<button class="btn btn-primary" type="button" ng-click="ctrl.cancel()">Close</button>'+
                        '<button class="btn btn-success" type="button" ng-click="ctrl.ok()">Add</button>'+
                    '</div>'+
                '</div>',
                controller: function($uibModalInstance, users){
                    var ctrl = this;
                    ctrl.allUsers = [];
                    ctrl.user = null;
                    existUsersIds = [];
                    if(users) {
                        angular.forEach(users, function(i){
                            existUsersIds.push(i.User.Id);
                        })
                    }
                    ctrl.getUsers = function($select) {
                        if(!$select.search || $select.search.length < 3) return;
                        $ApiService.getUser($select.search).then(function(res){
                            ctrl.allUsers = res.filter(function(f) {
                                return existUsersIds.indexOf(f.Id) == -1;
                            });
                        });
                    };
                    ctrl.ok = function () {
                        $uibModalInstance.close(ctrl.user);
                    };
                    
                    ctrl.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                    };
                },
                controllerAs: 'ctrl',
                appendTo: angular.element(document.querySelectorAll('.app-container')),
                resolve: {
                    users: function(){
                        return ctrl.allUsers;
                    }
                }
            });
            modalInstance.result.then(function (user) {
                addUserList(user);
            }, function () {
            });
        }
        
        function addUserList(user) {
            $ApiService.getListItems('LearningsManagers', '$select=*,Users/Title,Users/Id,Users/EMail&$expand=Users&$filter=ManagerId eq ' + _spPageContextInfo.userId)
            .then(function(res){
                if(res[0]) {
                    var ids = res[0].UsersId;
                    ids.push(user.Id);
                    $ApiService.updateItem('LearningsManagers', res[0].Id, {
                        UsersId: {
                            results: ids
                        },
                        '__metadata': {
                            type: 'SP.Data.LearningsManagersListItem'
                        },
                    }).then(function(res){
                        getData();
                    })

                }
                else {
                    $ApiService.createItem('LearningsManagers', {
                        Title: _spPageContextInfo.userId.toString(),
                        ManagerId: _spPageContextInfo.userId,
                        UsersId: {
                            results: [user.Id]
                        },
                        '__metadata': {
                            type: 'SP.Data.LearningsManagersListItem'
                        },
                    }).then(function(res){
                        getData();
                    })

                }
            });
        }

        ctrl.manageUser = function(userId) {
            $location.path('/manager-dashboard/' + userId);
        }

        ctrl.close = function(){
            $location.path('/');
        }

        	
        ctrl.getTopicHours = function(val){
            if(!val) return 0+' min';
            var result = '';
            if(val<60){
                result = val + ' min';
            }
            else {
                result = parseInt(val/60) + ' hour '+ (val%60) + ' min';
            }
            return result;
        }	

        ctrl.addTopicForUser = function() {
            var modalInstance = $uibModal.open({
                animation: true,
                size: 'lg',
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                templateUrl:  _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/modal/addTopicForUser-view.html',
                controller: function($uibModalInstance, $ApiService, $q, userTopics){
                    var ctrl = this;
                    ctrl.item = {};
                    ctrl.categories = [];
                    ctrl.allMainLinks = [];
                    ctrl.allSubcards = [];
                    ctrl.allTopics = [];
                    var filter = [];
                    angular.forEach(userTopics, function(v){
                        filter.push("Id ne "+v.LearningsTopicId);
                    });
                    filter.push("TopicType eq \'Manager\'");

                    var request = {
                        // categories: $ApiService.getListItems('LearningCategories', '$orderBy=SortOrder'),
                        // allMainLinks: $ApiService.getListItems('MainLinks', "$orderBy=SortOrder&$filter=Status eq 'Active'"),
                        // allSubcards: $ApiService.getListItems('Subcards Links', "$orderBy=SortOrder&$select=*,ParentLink/Title&$expand=ParentLink&$filter=Status eq 'Active'"),
                        allTopics: $ApiService.getListItems('LearningsTopics', '$orderBy=SortOrder&$filter='+filter.join(' and '))
                    };
            
                    $q.all(request).then(function(res){
                        // ctrl.categories = res.categories;
                        // ctrl.allMainLinks = res.allMainLinks;
                        // ctrl.allSubcards = res.allSubcards;
                        ctrl.allTopics = res.allTopics;
                    });
                    	
                    ctrl.getTopicHours = function(val){
                        if(!val) return 0+' min';
                        var result = '';
                        if(val<60){
                            result = val + ' min';
                        }
                        else {
                            result = parseInt(val/60) + ' hour '+ (val%60) + ' min';
                        }
                        return result;
                    }	
                    ctrl.ok = function () {
                        $uibModalInstance.close(ctrl.item);
                    };
                    
                    ctrl.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                    };
                },
                controllerAs: 'ctrl',
                appendTo: angular.element(document.querySelectorAll('.app-container')),
                resolve: {
                    userTopics: function(){
                        return ctrl.userTopics.filter(function(f){return f.TopicType == 'Manager';});
                    }
                }
            });
            modalInstance.result.then(function (topic) {
                addManagerTopic(topic);
            }, function () {
            });
        }

        function addManagerTopic(topic) {
            $ApiService.createItem('LearningsTopicsLog', {
                Title: topic.Topic.Title,
                LearningsTopicId: topic.Topic.Id,
                TopicType: 'Manager',
                Status: 'New',
                UserId: ctrl.userId,
                '__metadata': {
                    type: 'SP.Data.LearningsTopicsLogListItem'
                },
            }).then(function(){
                getData();
            });
        }

        ctrl.exportToCSV = function(){
            //New_Put_Learning_Enrollment.csv
            var fileUrl = _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/New_Put_Learning_Enrollment.csv';
            var requests = {
                template: $ApiService.getFile(fileUrl),
                allTopics: $ApiService.getListItems('Topics', "$select=*,CourseID/CourseID&$expand=CourseID"),
                topicsLog: $ApiService.getListItems('TopicsLog', 
                "$filter=Status eq 'Completed'&$orderBy=Modified desc&$select=*,Topic/Title,SubcardsLink/Title,Author/Title,Author/EMail,Author/Name"+
                "&$expand=Topic,SubcardsLink,Author")
            };
            $q.all(requests).then(function(res){
                var data = CSVToArray(res.template.data);
                if(data[data.length-1].length == 1) data.splice(data.length-1, 1);
                ctrltopicsLog = [];
                angular.forEach(res.topicsLog, function(value, index){
                    angular.forEach(res.allTopics, function(v){
                        if(value.TopicId == v.Id) {
                            res.topicsLog[index]['TopicItem'] = v; 
                        }
                    });
                });
                angular.forEach(res.topicsLog, function(topic, index){
                    var CourseID = [];
                    angular.forEach(topic.TopicItem.CourseID, function(val){
                        CourseID.push(val.CourseID);
                    });
                    data.push([
                        "",
                        index+1,
                        topic.Topic.Title,
                        topic.SubcardsLink.Title,
                        topic.Author.Name.substring(14,topic.Author.Name.length),
                        topic.Author.Title,
                        topic.Modified,
                        topic.Status,
                        CourseID.join(', '),
                    ]);
                });
                generateCSV(data);
            });
        }

        function generateCSV(data) {
            //$ApiService.getListItems('TopicsLog', "$orderBy=Modified desc&top=1&$filter=AuthorId eq "+_spPageContextInfo.userId)
            // console.log(data);
            var csvContent = "data:text/csv;charset=utf-8,";

            angular.forEach(data, function(rowArray) {
                var row = '';
                angular.forEach(rowArray, function(arr){
                    row += '\"' + arr + '\",';
                });
                // var row = rowArray.join(",");
                csvContent += row + "\r\n";
            });
            var encodedUri = encodeURI(csvContent);
            var link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", "New_Put_Learning_Enrollment.csv");
            document.body.appendChild(link); // Required for FF

            link.click();
        }
        function CSVToArray( strData, strDelimiter ){
            // Check to see if the delimiter is defined. If not,
            // then default to comma.
            strDelimiter = (strDelimiter || ",");
    
            // Create a regular expression to parse the CSV values.
            var objPattern = new RegExp(
                (
                    // Delimiters.
                    "(\\" + strDelimiter + "|\\r?\\n|\\r|^)" +
    
                    // Quoted fields.
                    "(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|" +
    
                    // Standard fields.
                    "([^\"\\" + strDelimiter + "\\r\\n]*))"
                ),
                "gi"
                );
    
    
            // Create an array to hold our data. Give the array
            // a default empty first row.
            var arrData = [[]];
    
            // Create an array to hold our individual pattern
            // matching groups.
            var arrMatches = null;
    
    
            // Keep looping over the regular expression matches
            // until we can no longer find a match.
            while (arrMatches = objPattern.exec( strData )){
    
                // Get the delimiter that was found.
                var strMatchedDelimiter = arrMatches[ 1 ];
    
                // Check to see if the given delimiter has a length
                // (is not the start of string) and if it matches
                // field delimiter. If id does not, then we know
                // that this delimiter is a row delimiter.
                if (
                    strMatchedDelimiter.length &&
                    (strMatchedDelimiter != strDelimiter)
                    ){
    
                    // Since we have reached a new row of data,
                    // add an empty row to our data array.
                    arrData.push( [] );
    
                }
    
    
                // Now that we have our delimiter out of the way,
                // let's check to see which kind of value we
                // captured (quoted or unquoted).
                if (arrMatches[ 2 ]){
    
                    // We found a quoted value. When we capture
                    // this value, unescape any double quotes.
                    var strMatchedValue = arrMatches[ 2 ].replace(
                        new RegExp( "\"\"", "g" ),
                        "\""
                        );
    
                } else {
    
                    // We found a non-quoted value.
                    var strMatchedValue = arrMatches[ 3 ];
    
                }
    
    
                // Now that we have our value string, let's add
                // it to the data array.
                arrData[ arrData.length - 1 ].push( strMatchedValue );
            }
    
            // Return the parsed data.
            return( arrData );
        }     
        
        ctrl.exportToPDF = function(){
            $GeneratePDF.generateAllUsersPDF(ctrl.allUsers, ctrl.topicsLog, ctrl.allUserTopicsLog);
        }

        ctrl.exportUserTopicsToPDF = function(){
            $GeneratePDF.generateUserPDF(ctrl.selectedUser, ctrl.topicsLog[ctrl.selectedUser.User.Id], ctrl.userTopics);
        }

        function groupBy(xs, prop) {
            return xs.reduce(function(rv, x) {


                  
              (rv[x[prop]] = rv[x[prop]] || []).push(x);
              return rv;
            }, {});
        }
    }
})();