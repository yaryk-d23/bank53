(function(){
    angular.module('App')
    .component('learningsTopics', {
        templateUrl: _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/learnings-topics/learningsTopics-view.html?rnd' + Math.random(),
        bindings: {
            //user: '<'
        },
        controllerAs: 'ctrl',
        controller: ['$ApiService', '$q', '$scope', '$routeParams', '$uibModal', '$window', '$location', formCtrl]
    });

    function formCtrl($ApiService, $q, $scope, $routeParams, $uibModal, $window, $location){
        var ctrl = this;
        ctrl.collapse = false;
        ctrl.showTopics = function(){
            ctrl.collapse = !ctrl.collapse;
        }
        ctrl.items = [];
        ctrl.userTopicsLog = [];
        getData();
        function getData(){
            var request = {
                userTopicsLog: $ApiService.getListItems('LearningsTopicsLog', '$filter=UserId eq ' + _spPageContextInfo.userId),
                userTopics: $ApiService.getListItems('LearningsTopics', '')
            };

            $q.all(request).then(function(res){
                ctrl.userTopicsLog = res.userTopicsLog;
                if(ctrl.userTopicsLog.length){
                    ctrl.userTopicsLog = [];
                    angular.forEach(res.userTopicsLog, function(value){
                        angular.forEach(res.userTopics, function(v){
                            if(value.LearningsTopicId == v.Id) {
                                var newItem = value;
                                newItem.LearningsTopic = v;
                                ctrl.userTopicsLog.push(newItem);
                            }
                        });
                    });
                }
            });
        }
        ctrl.onClickUserTopic = function(topic){
            $ApiService.updateItem('LearningsTopicsLog', topic.Id, {Status: 'In Progress', __metadata: {type:'SP.Data.LearningsTopicsLogListItem'}}).then(function(res){
                getData();
                if(topic.openInNewTab) {
                    ctrl.openInNewTab(topic.StartLink ? topic.StartLink.Url : '')
                }
                else {
                    ctrl.openModal(topic.LearningsTopic.Title, topic.StartLink ? topic.StartLink.Url : '')
                }
            });
        }
        ctrl.onCompleteUserTopic = function(itemId){
            $ApiService.updateItem('LearningsTopicsLog', itemId, {Status: 'Completed', __metadata: {type:'SP.Data.LearningsTopicsLogListItem'}}).then(function(res){
                getData();
            });
        }

        ctrl.openInNewTab = function(url){
            var win = window.open(url, '_blank');
            win.focus();
        }

        ctrl.openModal = function(title, url) {
            var modalInstance = $uibModal.open({
                animation: true,
                size: 'xl',
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                template: '<div class="modal-header">'+
                        '<button type="button" class="close" data-dismiss="modal" ng-click="ctr.cancel()" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
                        '<h2 class="modal-title text-center" id="modal-title">'+title+'</h2>'+
                    '</div>'+
                    '<div class="modal-body"><iframe width="100%" height="'+($window.innerHeight-150)+'px" src="'+url+'"</div>',
                controller: function($uibModalInstance){
                    var ctr = this;
                    ctr.cancel = function () {
                        $uibModalInstance.dismiss('cancel');
                      };
                },
                controllerAs: 'ctr',
                appendTo: angular.element(document.querySelectorAll('.app-container')),
                resolve: {}
            });
        }

        ctrl.collapseOther = function(id, itemId) {
            var list = $(".topic-description.collapse");
            $.each(list, function(key, el) {
                if($(el).attr('id') !== id) {
                    $(el).collapse('hide');
                }

            });
            $.each(ctrl.items, function(key, item) {
                if(item.Id != itemId) {
                    item.collapse = false;
                }
                if(item.Id == itemId) {
                    item.collapse = !item.collapse;
                }

            });

        }

        ctrl.getTopicHours = function(val){
            if(!val) return 0+' min';
            var result = '';
            if(val<60){
                result = val + ' min';
            }
            else {
                result = parseInt(val/60) + ' hour '+ (val%60) + ' min';
            }
            return result;
        }
    }
})();