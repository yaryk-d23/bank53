(function(){
    angular.module('App')
    .component('cards', {
        templateUrl: _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/cards/cards-view.html?rnd' + Math.random(),
        bindings: {
            //user: '<'
        },
        controllerAs: 'ctrl',
        controller: ['$ApiService', '$q', '$scope', '$routeParams', '$location', 'CONSTANTS', formCtrl]
    });

    function formCtrl($ApiService, $q, $scope, $routeParams, $location, CONSTANTS){
        var ctrl = this;
        ctrl.CONSTANTS = CONSTANTS;
        ctrl.parentId = $routeParams.id;
        ctrl.items = [];
        ctrl.parentLinkTitle ='';
		ctrl.defaultImage = 'https://thebank.info53.com/sites/RetailLearn/SiteAssets/app/RetailLearning/assets/img/noimage.png';
        var request = {
            items: $ApiService.getListItems('Cards', '$select=*,ParentLink/Title&$expand=ParentLink&$orderBy=SortOrder&$filter=ParentLinkId eq '+ ctrl.parentId),
        };
        $q.all(request).then(function(res){
            // CONSTANTS.setView(res.siteView[0].SecondLevel == 'Tiles' ? 'retail' : 'standart');
            // if(res.siteView[0].SecondLevel == 'Tiles'){
            //     if([...res.items,...res.items].length <= 3) {
            //         ctrl.items = chunk([...res.items,...res.items], 1);
            //     }
            //     else if([...res.items,...res.items].length >= 4 && [...res.items,...res.items].length <= 8) {
            //         ctrl.items = chunk([...res.items,...res.items], 2);
            //     }
            //     else {
            //         ctrl.items = chunk([...res.items,...res.items], 3);
            //     }
            // }
            // else {
            //    ctrl.items = res.items;
            // }
            ctrl.parentLinkTitle = res.items[0].ParentLink.Title;
            if(ctrl.CONSTANTS.SecondLevel == 'Tiles') {
                if(res.items.length <= 3) {
                    ctrl.items = chunk(res.items, res.items.length);
                }
                else if(res.items.length >= 4 && res.items.length <= 8) {
                    ctrl.items = chunk(res.items, Math.ceil(res.items.length/2));
                }
                else {
                    ctrl.items = chunk(res.items, Math.ceil(res.items.length/3));
                }
            }
            else {
                ctrl.items = res.items;
            }
            // $scope.$apply();
                
        });

        ctrl.loadLastTopic = function(e) {
            e.preventDefault();
            CONSTANTS.loadLastTopic();
        }

        function groupBy(xs, prop) {
            return xs.reduce(function(rv, x) {
              (rv[x[prop]] = rv[x[prop]] || []).push(x);
              return rv;
            }, {});
        }

        function chunk(array, size) {
            const chunked_arr = [];
            for (let i = 0; i < array.length; i++) {
              const last = chunked_arr[chunked_arr.length - 1];
              if (!last || last.length === size) {
                chunked_arr.push([array[i]]);
              } else {
                last.push(array[i]);
              }
            }
            return chunked_arr;
        }

        ctrl.goBack = function(e){
			e.preventDefault();
			history.back();
        }
    }
})();