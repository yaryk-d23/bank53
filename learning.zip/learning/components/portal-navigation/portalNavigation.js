(function(){
    angular.module('App')
    .component('portalNavigation', {
        templateUrl: _spPageContextInfo.webServerRelativeUrl + '/SiteAssets/app/Leadership/app/components/portal-navigation/portalNavigation-view.html?rnd' + Math.random(),
        bindings: {
            //user: '<'
        },
        controllerAs: 'ctrl',
        controller: ['$ApiService', '$q', '$scope', 'CONSTANTS', formCtrl]
    });

    function formCtrl($ApiService, $q, $scope, CONSTANTS){
        var ctrl = this;
        ctrl.CONSTANTS = CONSTANTS;
        ctrl.allLink = [];
        $ApiService.getListItems('PortalNavigation', '$orderby=SortOrder').then(function(res){
            ctrl.allLink = groupBy(res, 'Category');
        });

        function groupBy(xs, prop) {
            return xs.reduce(function(rv, x) {
              (rv[x[prop]] = rv[x[prop]] || []).push(x);
              return rv;
            }, {});
        }
    }
})();