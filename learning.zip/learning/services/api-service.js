(function(){
    angular.module('App')
    .factory('$ApiService', function ($http, $q) {
        return {
            getListItems: getListItems,
            getListChoiceField: getListChoiceField,
            createItem: createItem,
            updateItem: updateItem,
            getUser: getUser,
            getFile: getFile,
            getList: getList
        };

        function getList(siteUrl, listTitle) {
            return $http.get(siteUrl + "/_api/Web/lists?$filter=Title eq '"+ listTitle +"'")
                .then(function(res){
                    return res.data.value;
                });
        }

        function getFile(fileUrl) {
            
            return $http.get(_spPageContextInfo.webAbsoluteUrl + "/_api/Web/GetFileByServerRelativeUrl('"+ fileUrl +"')/$value")
                .then(function(res){
                    return res;
                });
        }

        function getListItems(listTitle, params){
            return $http.get(_spPageContextInfo.webAbsoluteUrl + '/_api/web/lists/getbytitle(\''+listTitle+'\')/items?' + params)
                .then(function(res){
                    return res.data.value;
                });
        }

        function getListChoiceField(listTitle, fieldName){
            return $http({
                        url: _spPageContextInfo.webAbsoluteUrl + 
                            '/_api/web/lists/getbytitle(\''+listTitle+'\')/fields?'+
                            '$filter=EntityPropertyName eq \''+fieldName+'\'',
                        
                        headers: {
                            "accept": "application/json;odata=verbose",
                            "content-type": "application/json;odata=verbose"
                        }
                    }).then(function(res){
                        return res.data.d.results[0];
                    });
        }

        function createItem(listTitle, data, params) {
            return $http({
                url: _spPageContextInfo.webAbsoluteUrl + '/_api/web/lists/getbytitle(\''+listTitle+'\')/items?' + params, 
                method: 'POST',
                data: data, 
                headers: {
                    "accept": "application/json;odata=verbose",
                    "content-type": "application/json;odata=verbose",
                    "X-RequestDigest": $('#__REQUESTDIGEST').val()
                }
            })
            .then(function(res){
                return res;
            });
        }

        function updateItem(listTitle, itemId, data) {

            return $http({
                url: _spPageContextInfo.webAbsoluteUrl + '/_api/web/lists/getbytitle(\''+listTitle+'\')/items('+itemId+')', 
                method: 'POST',
                data: data, 
                headers: {
                    "accept": "application/json;odata=verbose",
                    "content-type": "application/json;odata=verbose",
                    "X-RequestDigest": $('#__REQUESTDIGEST').val(),
                    "IF-MATCH": "*",  
                    "X-HTTP-Method": "MERGE"
                }
            })
            .then(function(res){
                return res;
            });
        }

        function getUser(query){
            var url = _spPageContextInfo.webAbsoluteUrl +
                "/_api/web/siteusers?"+
                "$select="+[
                    "Id",
                    "Title",
                    "Email",
                    "LoginName"
                ].join(",")+
                "&$top=20"+
                "&$filter=("+[
                    "substringof('" + query + "',Title)",
                    "substringof('" + query + "',Email)",
                    "substringof('" + capitalizeFirstLetter(query) + "',Title)",
                    "substringof('" + capitalizeFirstLetter(query) + "',Email)"
                ].join(" or ")
                + ") and PrincipalType eq 1";
            return $http({
                method: 'GET',
                headers: {
                    "accept": "application/json;odata=verbose",
                    "content-type": "application/json;odata=verbose"
                },
                url: url                    
            }).then(function (res) {
                return res.data.d.results;
            });
        }

        function capitalizeFirstLetter(string) {
            return string.charAt(0).toUpperCase() + string.slice(1);
        }

    });
})();