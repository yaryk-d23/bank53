angular.module('App')
    .factory('$GeneratePDF', ['$ApiService', function ($ApiService) {
        return {
            generateAllUsersPDF: generateAllUsersPDF,
            generateUserPDF: generateUserPDF
        };

        function generateUserPDF(user, topicsLog, allUserTopicsLog) {
            return new Promise(function(resolve, reject){
                var doc = new jsPDF('p', 'pt', 'a4');
                var drawHeaderRow= function (row, data) {
                    doc.setTextColor(68, 68, 68);
                    doc.setFillColor(255, 255, 255);
                    data.cursor.y += 20;
                }
                var customHeader = {
                    cellPadding: 0,
                    lineColor: [255, 255, 255],
                    halign: 'left',
                    valign: 'middle',
                    overflow: 'linebreak',
                    fontSize: 0,
                    fontStyle: 'normal',
                    fillColor:[255, 255, 255],
                    textColor: [0, 0, 0]
                }
                var cols = [{
                    title: '', dataKey: 'fullHeaderLG'
                }];
                var table = [];
                table.push({
                    fullHeaderLG: 'Fifth Third Private Bank'
                });
                var style = getUserStyle(10,true,drawHeaderRow, undefined, undefined, customHeader);
                doc.autoTable(cols ,table ,style);
                var cols = [{
                    title: '', dataKey: 'fullHeaderMD'
                }];
                var table = [];
                table.push({
                    fullHeaderMD: 'Manager Dashboard'
                });
                var style = getUserStyle(doc.autoTableEndPosY(),true,drawHeaderRow, undefined, undefined, customHeader);
                doc.autoTable(cols ,table ,style);
                var cols = [{
                    title: '', dataKey: 'fullHeaderS'
                }];
                var table = [];
                table.push({
                    fullHeaderS: '\n             '+user.User.Title
                });
                var style = getUserStyle(doc.autoTableEndPosY(),true,drawHeaderRow, undefined, undefined, customHeader);
                doc.autoTable(cols ,table ,style);
                var cell = doc.previousAutoTable.body[0].cells['fullHeaderS'];
                var image = getBase64Image(document.getElementById('user_image'));
                doc.addImage(image, 'JPG', cell.x+3, cell.y+3, 36, 36);

                var cols = [{
                    title: '', dataKey: 'fullHeaderS'
                }];
                var table = [];
                table.push({
                    fullHeaderS: ''
                });
                table.push({
                    fullHeaderS: 'Topics'
                });
                var style = getUserStyle(doc.autoTableEndPosY(),true,drawHeaderRow, undefined, undefined, customHeader);
                doc.autoTable(cols ,table ,style);
                var cols = [{
                    title: '', dataKey: 'fullHeaderXS'
                }];
                angular.forEach(topicsLog, function(val){
                    var table = [];
                    table.push({
                        fullHeaderXS: val.Topic.Title + ' - ' + val.Status
                    });
                    table.push({
                        fullHeaderXS: val.Topic.Description + '\n\n' + getTopicHours(val.Topic.Time) + " | " + val.Topic.Modality + " | " + val.Status
                    });
                    // table.push({
                    //     fullHeaderXS: getTopicHours(val.Topic.Time) + " | " + val.Topic.Modality + " | " + val.Status
                    // });

                    var style = getUserStyle(doc.autoTableEndPosY()+5,true,drawHeaderRow, undefined, undefined, customHeader);
                    doc.autoTable(cols ,table ,style);
                });


                //

                var cols = [{
                    title: '', dataKey: 'fullHeaderS'
                }];
                var table = [];
                table.push({
                    fullHeaderS: '\n'
                });
                table.push({
                    fullHeaderS: 'Learning Topics'
                });
                var style = getUserStyle(doc.autoTableEndPosY(),true,drawHeaderRow, undefined, undefined, customHeader);
                doc.autoTable(cols ,table ,style);

                var cols = [{
                    title: '', dataKey: 'fullHeaderXS'
                }];
                angular.forEach(allUserTopicsLog, function(val){
                    var table = [];
                    table.push({
                        fullHeaderXS: val.LearningsTopic.Title + ' - ' + val.Status + ' ('+ val.TopicType +')'
                    });
                    table.push({
                        fullHeaderXS: val.LearningsTopic.Description + '\n\n' + getTopicHours(val.LearningsTopic.Time) + " | " + val.LearningsTopic.Modality + " | " + val.Status
                    });
                    // table.push({
                    //     fullHeaderXS: getTopicHours(val.Topic.Time) + " | " + val.Topic.Modality + " | " + val.Status
                    // });

                    var style = getUserStyle(doc.autoTableEndPosY()+5,true,drawHeaderRow, undefined, undefined, customHeader);
                    doc.autoTable(cols ,table ,style);
                });
                var pageCount = doc.internal.getNumberOfPages();
                for(var i = 0; i < pageCount; i++){
                    doc.setPage(i+1);
                    doc.setFontSize(10);
                    doc.text(doc.internal.pageSize.width -110, doc.internal.pageSize.height-20, 'Page ' + (i+1) + ' of ' + pageCount);
                }
                // doc.output('dataurlnewwindow');
                doc.save(user.User.Title+" manager dashboard.pdf");
            });
        }

        function getTopicHours(val){
            if(!val) return 0+' min';
            var result = '';
            if(val<60){
                result = val + ' min';
            }
            else {
                result = parseInt(val/60) + ' hour '+ (val%60) + ' min';
            }
            return result;
        }
        function getUserStyle(startY,haveHeader,drawHeaderRow, drawCell, drawRow, customHeader, styles){
            var result = {
                includeHiddenHtml: true,
                margin: {
                            top: 20,
                            left: 50,
                            right: 50,
                            bottom: 50
                        },
                bodyStyles: {
                            textColor: [0, 0, 0],
                            lineColor:[220,220,220],
                            cellPadding: 7,
                            //rowHeight: 30,
                         },
                alternateRowStyles: { 
                            fillColor: [255, 255, 255],
                            lineWidth: 1,
                            lineColor:[0,0,0],
                          },
                styles: {
                            fontSize: 10,
                            fontStyle: 'bold',
                            valign: 'middle',
                            halign: 'center',
                            lineWidth: 1,
                            lineColor:[0,0,0],
                            overflow: 'linebreak'
                         },
                pageBreak: 'avoid',
                rowPageBreak: 'avoid',
                startY:startY + 5,
                columnStyles: {
                    col1: {cellWidth: 240, fontSize: 14, halign: 'left', fontStyle: 'normal'},
                    col2: {cellWidth: 240, fontSize: 14, halign: 'left', fontStyle: 'normal'},
                    val1: {cellWidth: 240, halign: 'left', fontStyle: 'normal', cellPadding: 10},
                    val2: {cellWidth: 240, halign: 'left', fontStyle: 'normal', cellPadding: 10},
                    fullHeaderLG: {
                        halign: 'center',
                        lineColor: [255,255,255],
                        fontStyle: 'normal',
                        fontSize: 20,
                        cellPadding: 3
                    },
                    fullHeaderMD: {
                        halign: 'center',
                        lineColor: [255,255,255],
                        fontStyle: 'normal',
                        fontSize: 16,
                        cellPadding: 3
                    },
                    fullHeaderS: {
                        halign: 'left',
                        lineColor: [255,255,255],
                        fontStyle: 'normal',
                        fontSize: 14,
                        cellPadding: 3
                    },
                    fullHeaderXS: {
                        halign: 'left',
                        lineColor: [255,255,255],
                        fontStyle: 'normal',
                        fontSize: 12,
                        cellPadding: 3
                    }
                      
                },
                createdCell: function(data) { 
                    if(data.column.dataKey === "fullHeaderXS" && data.row.index == 0) {
                        data.cell.styles.fontStyle = 'bold';
                    }
                    if(data.column.dataKey === "fullHeaderXS" && data.row.index == 1) {
                        data.cell.styles.lineColor = [220, 220, 220];
                        data.cell.styles.cellPadding = 8;
                    }
                    if(data.column.dataKey === "fullHeaderXS" && data.row.index == 2) {
                        data.cell.styles.fontSize = 10;
                    }
                    
                },
                
            };

            if(styles) {
                result.styles = styles;
            }
            if(drawHeaderRow)
                result.drawHeaderRow=drawHeaderRow; 
            if(drawCell)
                result.drawCell = drawCell;
            
            if(drawRow)
                result.drawRow = drawRow;
            if(haveHeader && !customHeader)
                result.headStyles = {
                        cellPadding: 8,
                        //rowHeight: 30,
                        lineColor: [199,217,229],
                        halign: 'left',
                        valign: 'middle',
                        overflow: 'visible',
                        fontSize: 16,
                        fontStyle: 'normal',
                        fillColor:[222, 242, 255],
                        textColor: [68,68,68]
                     };
             else if(customHeader)
                 result.headStyles  = customHeader;
             //else
            //    result.headerStyles={rowHeight:0};
            
            return result;
        
        }

        function generateAllUsersPDF(data, topicsLog, allUserTopicsLog) {
            return new Promise(function(resolve, reject){
                var doc = new jsPDF('p', 'pt', 'a4');
                var drawHeaderRow= function (row, data) {
                    doc.setTextColor(68, 68, 68);
                    doc.setFillColor(255, 255, 255);
                    data.cursor.y += 20;
                }
                var customHeader = {
                    cellPadding: 0,
                    lineColor: [255, 255, 255],
                    halign: 'left',
                    valign: 'middle',
                    overflow: 'linebreak',
                    fontSize: 0,
                    fontStyle: 'normal',
                    fillColor:[255, 255, 255],
                    textColor: [0, 0, 0]
                }
                var cols = [{
                    title: '', dataKey: 'fullHeaderLG'
                }];
                var table = [];
                table.push({
                    fullHeaderLG: 'Fifth Third Private Bank'
                });
                var style = getAllUsersStyle(10,true,drawHeaderRow, undefined, undefined, customHeader);
                doc.autoTable(cols ,table ,style);
                var cols = [{
                    title: '', dataKey: 'fullHeaderMD'
                }];
                var table = [];
                table.push({
                    fullHeaderMD: 'Manager Dashboard'
                });
                var style = getAllUsersStyle(doc.autoTableEndPosY(),true,drawHeaderRow, undefined, undefined, customHeader);
                doc.autoTable(cols ,table ,style);

                var cols = [{
                    title: '', dataKey: 'col1'
                },{
                    title: '', dataKey: 'col2'
                }];
                var table = [];
                table.push({
                    col1: "User", col2: ""
                });
                var style = getAllUsersStyle(doc.autoTableEndPosY()+10,true,drawHeaderRow, undefined, undefined, customHeader);
                doc.autoTable(cols ,table ,style);

                var cols = [{
                    title: '', dataKey: 'val1'
                },{
                    title: '', dataKey: 'val2'
                }];
                angular.forEach(data, function(val){
                    var table = [];
                    table.push({
                        val1: '                '+val.User.Title, val2: 'Topics:'+ (topicsLog[val.User.Id] ? topicsLog[val.User.Id].length : 0) +
                        '\nLearning Topics:' + (allUserTopicsLog[val.User.Id] ? allUserTopicsLog[val.User.Id].length : 0)
                    });
                    var style = getAllUsersStyle(doc.autoTableEndPosY()-5,true,drawHeaderRow, undefined, undefined, customHeader);
                    doc.autoTable(cols ,table ,style);
                    var cell = doc.previousAutoTable.body[0].cells['val1'];
                    var image = getBase64Image(document.getElementById('user_'+val.User.Id));
                    doc.addImage(image, 'JPG', cell.x+3, cell.y+3, 36, 36);
                });
                var pageCount = doc.internal.getNumberOfPages();
                for(var i = 0; i < pageCount; i++){
                    doc.setPage(i+1);
                    doc.setFontSize(10);
                    doc.text(doc.internal.pageSize.width -110, doc.internal.pageSize.height-20, 'Page ' + (i+1) + ' of ' + pageCount);
                }
                doc.save("manager-dashboard.pdf");
                // doc.output('dataurlnewwindow')

            });
        }

        function getAllUsersStyle(startY,haveHeader,drawHeaderRow, drawCell, drawRow, customHeader, styles){
            var result = {
                includeHiddenHtml: true,
                margin: {
                            top: 20,
                            left: 50,
                            right: 50,
                            bottom: 50
                        },
                bodyStyles: {
                            textColor: [0, 0, 0],
                            lineColor:[220,220,220],
                            cellPadding: 7,
                            //rowHeight: 30,
                         },
                alternateRowStyles: { 
                            fillColor: [255, 255, 255],
                            lineWidth: 1,
                            lineColor:[0,0,0],
                          },
                styles: {
                            fontSize: 10,
                            fontStyle: 'bold',
                            valign: 'middle',
                            halign: 'center',
                            lineWidth: 1,
                            lineColor:[0,0,0],
                            overflow: 'linebreak'
                         },
                pageBreak: 'auto',
                rowPageBreak: 'avoid',
                startY:startY + 5,
                columnStyles: {
                    col1: {cellWidth: 240, fontSize: 14, halign: 'left', fontStyle: 'normal'},
                    col2: {cellWidth: 240, fontSize: 14, halign: 'left', fontStyle: 'normal'},
                    val1: {cellWidth: 240, halign: 'left', fontStyle: 'normal', cellPadding: 10},
                    val2: {cellWidth: 240, halign: 'left', fontStyle: 'normal', cellPadding: 10},
                    fullHeaderLG: {
                        halign: 'center',
                        lineColor: [255,255,255],
                        fontStyle: 'normal',
                        fontSize: 20,
                        cellPadding: 3
                    },
                    fullHeaderMD: {
                        halign: 'center',
                        lineColor: [255,255,255],
                        fontStyle: 'normal',
                        fontSize: 16,
                        cellPadding: 3
                    }
                },
                createdCell: function(data) { 
                    if(data.column.dataKey === "col1" || data.column.dataKey === "col2") {
                        // data.cell.styles.fillColor = [103, 178, 232];
                        data.cell.styles.fontStyle = 'bold';
                        data.cell.styles.lineColor = [220, 220, 220];
                    }
                    if(data.column.dataKey === "val1" || data.column.dataKey === "val2") {
                        data.cell.styles.lineColor = [220, 220, 220];
                    }
                    
                },
                
            };

            if(styles) {
                result.styles = styles;
            }
            if(drawHeaderRow)
                result.drawHeaderRow=drawHeaderRow; 
            if(drawCell)
                result.drawCell = drawCell;
            
            if(drawRow)
                result.drawRow = drawRow;
            if(haveHeader && !customHeader)
                result.headStyles = {
                        cellPadding: 8,
                        //rowHeight: 30,
                        lineColor: [199,217,229],
                        halign: 'left',
                        valign: 'middle',
                        overflow: 'visible',
                        fontSize: 16,
                        fontStyle: 'normal',
                        fillColor:[222, 242, 255],
                        textColor: [68,68,68]
                     };
             else if(customHeader)
                 result.headStyles  = customHeader;
             //else
            //    result.headerStyles={rowHeight:0};
            
            return result;
        
        }

        function getBase64Image(img) {
            // Create an empty canvas element
            var canvas = document.createElement("canvas");
            canvas.width = img.width;
            canvas.height = img.height;
        
            // Copy the image contents to the canvas
            var ctx = canvas.getContext("2d");
            ctx.save();

            var x=0,y=0,width=canvas.width,height=canvas.height,radius=30;
            ctx.beginPath();
            ctx.moveTo(x + radius, y);
            ctx.lineTo(x + width - radius, y);
            ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
            ctx.lineTo(x + width, y + height - radius);
            ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
            ctx.lineTo(x + radius, y + height);
            ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
            ctx.lineTo(x, y + radius);
            ctx.quadraticCurveTo(x, y, x + radius, y);
            ctx.closePath();

            ctx.clip();
            ctx.drawImage(img,0,0, width, height);
            ctx.restore();
        
            // Get the data-URL formatted image
            // Firefox supports PNG and JPEG. You could check img.src to
            // guess the original format, but be aware the using "image/jpg"
            // will re-encode the image.
            var dataURL = canvas.toDataURL("image/png");
        
            //return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
            return dataURL;
        }
        
    }]);
