(function () {
  angular.module('App', [
    'ngRoute',
    'ngSanitize',
    'ui.bootstrap',
    'ngAnimate',
    'ui.select'
  ])
    .controller('AppCtrl', ['$ApiService', 'CONSTANTS', function ($ApiService, CONSTANTS) {
      var ctrl = this;
      ctrl.CONSTANTS = CONSTANTS;
      $(document).ready(function () {
        setInterval(function () {
          setContentWrapPadding();
        }, 300);
      });

      function setContentWrapPadding() {
        var footerHeight = $('.footer').height();
        $('.content-wrap').css('padding-bottom', footerHeight);
      }
      $ApiService.getListItems('Config', '$filter=Title eq \'Site Config\'').then(function (res) {
        if (res[0]) {
          CONSTANTS.set(res[0]);
        }
      });

    }])
    .constant('CONSTANTS', {
      FirstLevel: 'Standart',
      SecondLevel: 'Tiles',
      ThirdLevel: 'Carouser',
      BackgroundImage: '',
      HeaderImage: '',
      ShowFooter: '',
      ShowLastTopicButton: '',
      ShowDiscussionBoardButton: '',
      Survey: '',
      ShowPortalNavigationButton: '',
      ShowPortalMenu: '',
      set: function (data) {
        this.FirstLevel = data.FirstLevel;
        this.SecondLevel = data.SecondLevel;
        this.ThirdLevel = data.ThirdLevel;
        this.BackgroundImage = data.BackgroundImage ? data.BackgroundImage.Url : '';
        this.HeaderImage = data.HeaderImage ? data.HeaderImage.Url : '';
        this.ShowFooter = data.ShowFooter;
        this.ShowLastTopicButton = data.ShowLastTopicButton;
        this.ShowDiscussionBoardButton = data.ShowDiscussionBoardButton;
        this.Survey = data.Survey;
        this.ShowPortalNavigationButton = data.ShowPortalNavigationButton;
        this.ShowPortalMenu = data.ShowPortalMenu;
      }
    })
    .config(function ($routeProvider, $locationProvider) {
      $locationProvider.hashPrefix('');

      $routeProvider
        .when('/', {
          template: '<portal-cards></portal-cards>'
        }).when('/cards/:id', {
          template: '<cards></cards>'
        }).when('/learning/:parentLinkId', {
          template: '<portal-cards></portal-cards>'
        }).when('/learnings-survey', {
          template: '<learnings></learnings>'
        }).when('/learnings-dashboard', {
          template: '<learnings-dashboard></learnings-dashboard>'
        }).when('/manager-dashboard', {
          template: '<manager-dashboard></manager-dashboard>'
        }).when('/manager-dashboard/:userId', {
          template: '<manager-dashboard></manager-dashboard>'
        }).when('/navigation', {
          template: '<portal-navigation></portal-navigation>'
        }).when('/export-topics', {
          template: '<export-topics></export-topicss>'
        })
        .otherwise('/');
    })
    .filter('propsFilter', function () {
      return function (items, props) {
        var out = [];

        if (angular.isArray(items)) {
          var keys = Object.keys(props);

          items.forEach(function (item) {
            var itemMatches = false;

            for (var i = 0; i < keys.length; i++) {
              var prop = keys[i];
              var text = props[prop].toLowerCase();
              if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
                itemMatches = true;
                break;
              }
            }

            if (itemMatches) {
              out.push(item);
            }
          });
        } else {
          // Let the output be the input untouched
          out = items;
        }

        return out;
      };
    });
})();